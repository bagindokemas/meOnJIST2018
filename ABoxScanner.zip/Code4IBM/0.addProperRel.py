#add http://www.semanticweb.org/watson/ontologies/2017/1/it_kg_version1# to the relation

a = open("PBR(KGC(OKG))/IBMNewExpandedTripleInStr.txt")
b = open("PBR(KGC(OKG))/_IBMProperRel.txt","w")

for line in a:
	row=line.split()
	pred = "http://www.semanticweb.org/watson/ontologies/2017/1/it_kg_version1#"+row[1]
	b.write(row[0]+"\t"+pred+"\t"+row[2]+"\n")

b.close()

