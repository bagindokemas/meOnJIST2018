#make dictionary for IBM relation

x = open("TesEKAW11/IBMRelationDict.txt","w")

with open('Mate1/Iteration1/2ndPBR/ListofRelations.txt') as a:
	seenRel=set()
	#i dimulai dari 63917 karena Dictionary Instance maximalnya 63916 ,
	#2931 so, start from 2932
	i=1981
	for line in a:
		row=line.split()
		if(row[0] not in seenRel):
			seenRel.add(row[0])
			x.write(row[0]+"\t"+str(i)+"\n")		
			i += 1
		
x.close()
