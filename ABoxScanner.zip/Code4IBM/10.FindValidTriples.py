ori_all = open("TesEKAW11/_IBMProperRelInInt.txt")
invalid = open("TesEKAW11/NotValidWD.txt")
unknownWO = open("TesEKAW11/unknownWithoutOverlap.txt")

valid = open("TesEKAW11/valid.txt","w")

dictInvalid={}
for iB,lineB in enumerate(invalid):
	kB = lineB
	vB = iB
	dictInvalid[kB]=vB

dictUnknown={}
for iC,lineC in enumerate(unknownWO):
	kC = lineC
	vC = iC
	dictUnknown[kC]=vC

for lineA in ori_all:
	if (lineA not in dictInvalid) and (lineA not in dictUnknown):
		valid.write(lineA)

valid.close()


