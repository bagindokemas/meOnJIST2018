#a = open("/home/rpgsbs/r01krw16/KGCTools/STransE/Datasets/NELL_ISWC/NewExpandedTripleKB2EInStr.txt")
a = open("IC3Flow2-Ite1/validLabels.txt")
b = open("IC3Flow2-Ite1/validLabelForMat.txt","w")

for line in a:
	row=line.split()
	b.write("concept_"+row[0]+"\t"+"concept_"+row[1]+"\t"+"concept_"+row[2]+"\n")


b.close()