a = open("EKAW6Exp/forPBRWD.txt")
b = open("EKAW6Exp/validLabel.txt")
c = open("EKAW6Exp/unknownLabel.txt")
d = open("EKAW6Exp/NotValidLabel.txt")

e=open("EKAW6Exp/missingTriplesX.txt","w")

ValidDict = {}
for i1,lineV in enumerate(b):
	k1 = lineV
	v1 = i1
	ValidDict [k1]=v1

NotValidDict = {}
for i2,line2 in enumerate(d):
	k2 = line2
	v2 = i2
	NotValidDict [k2]=v2

UnknownDict = {}
for i3,line3 in enumerate(c):
	k3 = line3
	v3 = i3
	NotValidDict [k3]=v3

foundA = 0
foundB = 0
foundC = 0
for lineA in a:
	#if (lineA not in ValidDict) and (lineA not in NotValidDict) and (lineA not in UnknownDict):
	if (lineA in ValidDict):
		foundA = 1
	if (lineA in NotValidDict):
		foundB = 1
	if (lineA in UnknownDict):
		foundC = 1

	if(foundA==0 and foundB==0 and foundC==0):
		e.write(lineA)
	else:
		foundA = 0
		foundB = 0 
		foundC = 0
		
e.close()
	



