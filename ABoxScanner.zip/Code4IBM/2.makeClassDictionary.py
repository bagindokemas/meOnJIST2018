#make dictionary for IBM classes

x = open("TesEKAW11/IBMClassDict.txt","w")

with open('Mate1/Iteration1/2ndPBR/ListofClasses.txt') as a:
	seenClass=set()
	#i dimulai dari 64811 karena Dictionary relation maximalnya 64810
	#2944 so start from 2945
	i=1994

	for line in a:
		row=line.split()
		if(row[0] not in seenClass):
			seenClass.add(row[0])
			x.write(row[0]+"\t"+str(i)+"\n")		
			i += 1
		
x.close()
