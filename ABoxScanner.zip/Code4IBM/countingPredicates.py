#script for counting the predicates
a = open("/home/rpgsbs/r01krw16/KGCTools/KemScript/_IBM/NewPBR/Mate1/Iteration1/2ndPBR/KB2EOutput.txt")

seen = set()
count=0

for line in a:
	row=line.split()
	if(row[1] not in seen):
		seen.add(row[1])
		count = count+1

print count
