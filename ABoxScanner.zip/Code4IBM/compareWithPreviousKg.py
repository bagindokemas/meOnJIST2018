#script for comparing the KG from end of iteration with the KG from previous iteration

a = open("Embedding1/Iteration1/endOfIteration/InputIte1.txt")
b = open("Embedding1/Iteration1/endOfIteration/Iteration1.txt")
new = open("Embedding1/Iteration1/endOfIteration/NewInIteration1.txt","w") 

dictOld = {}
for iA,lineA in enumerate(a):
	kA = lineA
	vA = iA
	dictOld[kA] = vA

for lineB in b:
	if(lineB not in dictOld):	
		new.write(lineB)

new.close()

