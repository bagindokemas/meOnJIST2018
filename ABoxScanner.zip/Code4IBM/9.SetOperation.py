from sets import Set

unknown = set(open("TesEKAW11/UnknownWD.txt"))
overlap = set(open("TesEKAW11/OverlapTripleTemp.txt"))


c = open("TesEKAW11/unknownWithoutOverlap.txt","w")

unknownWithoutOverlap = unknown-overlap 

for line in unknownWithoutOverlap:
	c.write(line)

c.close()


