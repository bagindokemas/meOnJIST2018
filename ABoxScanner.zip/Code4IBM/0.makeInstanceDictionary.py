#script ini untuk membuat dictionary IBM

output = open("TesEKAW11/IBMInstanceDictionary.txt","w")


#with open('/home/rpgsbs/r01krw16/KGCTools/KemScript/_NELL-995Iteration/NELLWithPreCompute/rawKBWithProperRel.txt') as a:
with open('TesEKAW11/forPBR.txt') as a:

	seen=set()
	#seenRel = set()
	i = 0
	for line in a:
		row=line.split()
		if(row[0] not in seen):
			seen.add(row[0])
			output.write(row[0]+"\t"+str(i)+"\n")		
			i += 1			

		if(row[2] not in seen):
			seen.add(row[2])
			output.write(row[2]+"\t"+str(i)+"\n")
			i += 1

output.close

	

