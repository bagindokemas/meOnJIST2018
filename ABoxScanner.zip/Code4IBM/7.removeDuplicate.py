a = open("TesEKAW11/NotValid.txt")
b = open("TesEKAW11/NotValidWD.txt","w")

seen = set()
for line in a:
	if line not in seen:
		seen.add(line)
		b.write(line)

b.close()
