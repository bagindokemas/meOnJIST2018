#script for linking instance and class
import pdb

a = open("TesEKAW11/IBMInstanceDictionary.txt")
b = open("TesEKAW11/IBMClassDict.txt")
c = open("Mate1/Iteration1/2ndPBR/Instance_Class.txt")
x = open("TesEKAW11/Instance_ClassInInteger.txt","w")

#format output:
#kolom pertama : ID instance misalnya 78 
#kolom kedua : ID class misalnya 1000
#check apakah kolom pertama Instance Dictionary ada di instance_class
ins_class_str={}
for lineC in c:
	rowC = lineC.split()
	#kolom 1 adalah instance, 
	#kolom 2 adalah integer
	kC = rowC[0]
	vC = rowC[1]
	ins_class_str[kC] = vC

classDict = {}
for lineB in b:
	rowB = lineB.split()
	#kolom 1 adalah string Class IBM 
	#kolom 2 adalah integer
	k = rowB[0] 
	v = rowB[1]
	classDict[k]=v

for lineA in a:
	rowA = lineA.split()
	if rowA[0] in ins_class_str:
		#ambil rowA[1] sbg id instance 
		strClass = ins_class_str[rowA[0]]
		if strClass in classDict:
			x.write(rowA[1]+"\t"+classDict[strClass]+"\n")
	
x.close()		
