from sets import Set

unknownWD = set(open("EKAW10ExpReverse/UnknownWD.txt"))
overlap = set(open("EKAW10ExpReverse/OverlapTripleTemp.txt"))

c = open("EKAW10ExpReverse/unknownWO.txt","w")

unknownWithoutOverlap = unknownWD-overlap 

for line in unknownWithoutOverlap:
	c.write(line)

c.close()


