#script for linking instance and class 
import pdb
a = open("EKAW10ExpReverse/DBPediaInstanceDictionary.txt")
b = open("EKAW10ExpReverse/DBPediaClassDict.txt")
c = open("../DBPedia/2016-04/instance_Class.txt")

x = open("EKAW10ExpReverse/InstanceID2ClassID.txt","w")

#algoritma:
#for each line in a, take the instance label and search in c the class label for it
#after getting the class label, search the id of the class label in b,
#output the second column of a and the second column of b

instance_classDict={}
for lineC in c:
	rowC = lineC.split()
	k = rowC[0] #label instance
	v = rowC[2] #label class
	instance_classDict[k]=v

classDict = {}
for lineB in b:
	rowB = lineB.split()
	#kolom 1 adalah label Class DBPEdia 
	#kolom 2 adalah integer
	k = rowB[0] 
	v = rowB[1]
	classDict[k]=v

classID = ""
for lineA in a:
	#a punya 2 kolom
	#kolom 1: label instance dan kolom 2: ID
	rowA = lineA.split()
	if rowA[0] in instance_classDict:
		classLabel = instance_classDict[rowA[0]]
		if classLabel in classDict:
			classID = classDict[classLabel] 

	x.write(rowA[1]+"\t"+classID+"\n")

x.close()		
