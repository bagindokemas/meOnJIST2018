a = open("EKAW10ExpReverse/NotValid.txt")
b = open("EKAW10ExpReverse/NotValidWD.txt","w")

seen = set()
for line in a:
	if line not in seen:
		seen.add(line)
		b.write(line)

b.close()
