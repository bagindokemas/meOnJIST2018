from sets import Set

ori_all = set(open("EKAW10ExpReverse/_DBPediaInInteger.txt"))
invalid = set(open("EKAW10ExpReverse/NotValidWD.txt"))
unknownWO = set(open("EKAW10ExpReverse/unknownWO.txt"))

c = open("EKAW10ExpReverse/validTriples.txt","w")

validTriple = ori_all-invalid-unknownWO

for line in validTriple :
	c.write(line)

c.close()


