#make dictionary for DBPedia classes

x = open("EKAW10ExpReverse/DBPediaClassDict.txt","w")

with open('Data/ListofClasses.txt') as a:
	seenClass=set()
	#i dimulai dari 39816 karena Dictionary relation maximalnya 39816
	i=135986
	for line in a:
		row=line.split()
		if(row[0] not in seenClass):
			seenClass.add(row[0])
			x.write(row[0]+"\t"+str(i)+"\n")		
			i += 1
		
x.close()
